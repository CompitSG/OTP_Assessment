﻿using FakeItEasy;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using OTP.Application.Handlers.CommandHandler;
using OTP.Core.Repositories.Command;
using System.Collections.ObjectModel;
using System.Net;
using WebOTP.API.Controllers;
using Xunit;

namespace OTP.UnitTest
{
    private readonly IDbContext _mockDbContext;

    public CreateTodoListHandlerTests()
    {
        _mockDbContext = MockTodoListDbContext.GetDbContext().Object;
    }

    [Fact]
    public async Task GetAllTodoListsTest()
    {
        var handler = new GetAllTodoListsHandler(_mockDbContext);
        var result = await handler.Handle(new GetAllTodoListsRequest(), CancellationToken.None);
        result.ShouldBeOfType<GetAllTodoListsResponse>();
        result.TodoLists.ShouldBeOfType<ReadOnlyCollection<GetAllTodoListsDto>>();
        result.TodoLists.Count.ShouldBe(2);
    }
}