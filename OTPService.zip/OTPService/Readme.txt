1. Configure your local connectionstring in appsetings
2. Package Manager Console> Add-Migration urmigrationname
3. Package Manager Console> update-Database -Verbose
4.In CreateOtpHandler file, add your gmail related configuration.
