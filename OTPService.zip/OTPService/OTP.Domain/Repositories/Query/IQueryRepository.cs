﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OTP.Core.Repositories.Query
{
    public interface IQueryRepository<T> where T : class
    {
        // Generic repository for all if any
    }
}
