﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OTP.Core.Entities
{
    public class UserDetail : BaseEntity
    {
        public string Email { get; set; }
        public int? Otp { get; set; }
        public int TryCount { get; set; }
    }
}
