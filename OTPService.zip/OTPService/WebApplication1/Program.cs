using MediatR;
using FluentValidation.AspNetCore;
using OTP.Application.Interface;
using OTP.InfraStructure.Data;
using System.Configuration;
using System.Reflection;
using OTP.InfraStructure;
using OTP.InfraStructure.Repository;
using Microsoft.EntityFrameworkCore;
using Microsoft.OpenApi.Models;
using Microsoft.Extensions.Configuration;
using OTP.Application.Models;
using Microsoft.AspNetCore.Hosting;
using OTP.Core.Repositories.Command;
using OTP.Core.Repositories.Query;
using OTP.InfraStructure.Repository.Command;
using OTP.Application.Handlers.CommandHandler;
using Microsoft.Extensions.DependencyInjection;
using OTP.InfraStructure.Repository.Query;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
builder.Services.AddDbContext<EmailOtpDbContext>(options =>
                options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection"),
                b => b.MigrationsAssembly(typeof(EmailOtpDbContext).Assembly.FullName)
                   .EnableRetryOnFailure(maxRetryCount: 10, maxRetryDelay: TimeSpan.FromSeconds(10), errorNumbersToAdd: null)));
builder.Services.AddScoped<IOtpContext>(provider => provider.GetService<IOtpContext>());
builder.Services.AddSingleton(builder.Services.Configure<EmailConfig>(builder.Configuration.GetSection(nameof(EmailConfig))));
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddAutoMapper(typeof(Program));
builder.Services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(CreateOtpHandler).Assembly));
builder.Services.AddScoped(typeof(IQueryRepository<>), typeof(QueryRepository<>));
builder.Services.AddTransient<IUserQueryRepository, UserQueryRepository>();
builder.Services.AddScoped(typeof(ICommandRepository<>), typeof(CommandRepository<>));
builder.Services.AddTransient<OTP.Core.Repositories.Command.IUserCommandRepository, UserCommandRepository>();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "Email OTP Validator API",
        Version = "v1",
        Description = "API to generate Otp and validate"
    });
    c.EnableAnnotations();
    c.OrderActionsBy((apiDesc) => $"{apiDesc.ActionDescriptor.RouteValues["controller"]}_{apiDesc.HttpMethod}");

    var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
    var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
});

builder.Services.AddSwaggerGen();
builder.Services.AddControllers().AddFluentValidation(options =>
{
    options.ImplicitlyValidateChildProperties = true;
    options.ImplicitlyValidateRootCollectionElements = true;
    options.RegisterValidatorsFromAssembly(Assembly.GetExecutingAssembly());
});
var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseAuthorization();

app.MapControllers();

app.Run();
