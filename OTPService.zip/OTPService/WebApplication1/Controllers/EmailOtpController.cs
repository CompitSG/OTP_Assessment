﻿using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OTP.Application.Commands;
using OTP.Application.Exceptions;
using OTP.Application.Queries;
using Swashbuckle.AspNetCore.Annotations;
using System;
using WebOTP.API.Models;

namespace WebOTP.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmailOtpController : ControllerBase
    {
        private readonly IMediator _mediator;
        public EmailOtpController(IMediator mediator)
        {
            _mediator = mediator;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="createOtpCommand"></param>
        /// <returns></returns>
        [HttpPost("GenerateOtp")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> Generate([FromBody] CreateOtpCommand   createOtpCommand)
        {
            try
            {
                var data = await _mediator.Send(createOtpCommand);
                return StatusCode(StatusCodes.Status200OK, data);
            }
            catch (DisabledException disabledException)
            {
                return StatusCode(StatusCodes.Status400BadRequest, disabledException.Message);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, Constants.InternalServerError);
            }
        }

        /// <summary>
        /// /
        /// </summary>
        /// <param name="otpCommand"></param>
        /// <returns></returns>
        [Route("validateOtp")]
        [HttpPut]
        [SwaggerOperation(Summary = Constants.Validate, Description = Constants.ValidateAnOtp)]
        [SwaggerResponse(200, Type = typeof(string))]
        [SwaggerResponse(400, Type = typeof(CustomRespnse))]
        [SwaggerResponse(404, Type = typeof(CustomRespnse))]
        [SwaggerResponse(500, Type = typeof(CustomRespnse))]
        public async Task<IActionResult> Validate([FromBody] ValidateOTP otpCommand)
        {
            try
            {
                if (await _mediator.Send(otpCommand))
                {
                    return StatusCode(StatusCodes.Status200OK, "Validated succesfully.");
                }
                return StatusCode(StatusCodes.Status200OK, "Invalid Otp entered.");
            }
            catch (TimeOutException timeOutException)
            {
                return StatusCode(StatusCodes.Status400BadRequest, timeOutException.Message);
            }
            catch (NotFoundException notFoundException)
            {
                return StatusCode(StatusCodes.Status400BadRequest, notFoundException.Message);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, Constants.InternalServerError);
            }

        }
    }
}
