﻿namespace WebOTP.API.Models
{
    public class OtpRequestDto
    {
        public string Email { get; set; }
    }
}
