﻿using Microsoft.AspNetCore.Mvc;
using OTP.Application.Exceptions;
using System.Text.Json.Serialization;

namespace WebOTP.API.Models
{
    public class CustomRespnse : ProblemDetails
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public CustomRespnse() { }

        /// <summary>
        /// Constructor with parameters
        /// </summary>
        /// <param name="errors"></param>
        public CustomRespnse(List<InvalidParameter> errors)
        {
            InvalidParams = errors;
        }
        /// <summary>
        /// Trace Id
        /// </summary>
        [JsonPropertyName("trace-id")]
        public string TraceId { get; set; }

        /// <summary>
        /// Invalid Params
        /// </summary>
        [JsonPropertyName("invalid-param")]
        public List<InvalidParameter> InvalidParams { get; set; } = new List<InvalidParameter>();
    }
}

