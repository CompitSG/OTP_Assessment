﻿using FluentValidation;
using OTP.Application.Queries;

namespace WebOTP.API.Helpers
{
    public class ValidateOtpValidator : AbstractValidator<ValidateOTP>
    {
        /// <summary>
        /// ValidateOtpValidator
        /// </summary>
        public ValidateOtpValidator()
        {
            RuleFor(_ => _.Otp).Cascade(CascadeMode.Stop).
                NotEmpty().WithMessage(Constants.OtpIsEmpty);
            RuleFor(_ => _.Email).Cascade(CascadeMode.Stop).
                NotEmpty().WithMessage(Constants.EmailIsEmpty)
                .Must(EmailValidator.IsValidEmail).WithMessage(Constants.EmailIsInvalid);
        }
    }
}
