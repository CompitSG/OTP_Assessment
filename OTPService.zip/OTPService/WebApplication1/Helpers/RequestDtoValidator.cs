﻿using FluentValidation;
using Microsoft.VisualBasic;
using OTP.Application.Commands;
using WebOTP.API.Models;

namespace WebOTP.API.Helpers
{
    public class RequestDtoValidator: AbstractValidator<CreateOtpCommand>
    {
        /// <summary>
        /// RequestDtoValidator
        /// </summary>
        public RequestDtoValidator()
    {
      
        RuleFor(_ => _.Email).Cascade(CascadeMode.Stop).
            NotEmpty().WithMessage(Constants.EmailIsEmpty);
        RuleFor(_ => _.Email).Cascade(CascadeMode.Stop).
            NotEmpty().WithMessage(Constants.EmailIsEmpty)
            .Must(EmailValidator.IsValidEmail).WithMessage(Constants.EmailIsInvalid);
    }
}
}

