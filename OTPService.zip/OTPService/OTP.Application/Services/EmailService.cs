﻿//using OTP.Application.Interface;
//using OTP.Application.Models;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Net;
//using System.Net.Mail;
//using System.Text;
//using System.Threading.Tasks;

//namespace OTP.Application.Services
//{
//    public class EmailService: IEmailService
//    {
//        private readonly SmtpClient _smtpClient;

//        public EmailService()
//        {
//            _smtpClient = new SmtpClient("smtp.gmail.com")
//            {
//                Port = 587,
//                Credentials = new NetworkCredential("pradeep.venkadachalam@gmail.com", "jzovleeufespdztp"),
//                EnableSsl = true,
//            };
//        }
//        public async Task<bool> SendEmail(EmailDetails emailData)
//        {
//            try
//            {

//                var mailMessage = new MailMessage(emailData.FromEmail, "pradeepvenkadachalam@gmail.com", "OTP Verification", emailData.Content);
//                await _smtpClient.SendMailAsync(mailMessage);
//                return true;
//            }
//            catch (Exception)
//            { return false; }
//        }
//    }
//}
