﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OTP.Application.Exceptions
{/// <summary>
 /// DisabledException
 /// </summary>
    public class DisabledException : Exception
    {
        public DisabledException()
        {

        }

        public DisabledException(string message)
            : base(message)
        {

        }
    }
}
