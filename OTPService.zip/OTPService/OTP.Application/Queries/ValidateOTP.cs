﻿using MediatR;
using OTP.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OTP.Application.Queries
{
    public class ValidateOTP : IRequest<bool>
    {
        public string Email { get; set; }
        public int? Otp { get; set; }
    }
}
