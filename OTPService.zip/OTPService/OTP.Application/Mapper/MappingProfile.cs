﻿using AutoMapper;
using OTP.Application.Commands;
using OTP.Application.Response;
using OTP.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OTP.Application.Mapper
{
    internal class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<UserDetail, CreateUserResponse>().ReverseMap();
            CreateMap<UserDetail, CreateOtpCommand>().ReverseMap();
        }
    }
}

