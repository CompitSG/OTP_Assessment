﻿using Microsoft.EntityFrameworkCore;
using OTP.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OTP.Application.Interface
{
    public interface IOtpContext
    {
        DbSet<UserDetail> UserDetail { get; set; }
        Task<int> SaveChangesAsync(CancellationToken cancellationToken = new CancellationToken());
    }
}
