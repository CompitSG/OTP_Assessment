﻿using MediatR;
using OTP.Application.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OTP.Application.Commands
{
    public class CreateOtpCommand : IRequest<CreateUserResponse>
    {
        public string Email { get; set; }
    }
}