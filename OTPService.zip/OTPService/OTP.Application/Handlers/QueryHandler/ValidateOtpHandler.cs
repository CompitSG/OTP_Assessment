﻿using MediatR;
using OTP.Application.Exceptions;
using OTP.Application.Extensions;
using OTP.Application.Queries;
using OTP.Core.Repositories.Command;
using OTP.Core.Repositories.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.WebRequestMethods;

namespace OTP.Application.Handlers.QueryHandler
{
    public class ValidateOtpHandler : IRequestHandler<ValidateOTP, bool>
    {
        private readonly IMediator _mediator;
        private readonly IUserCommandRepository _customerCommandRepository;
        private readonly IUserQueryRepository _userQueryRepository;

        public ValidateOtpHandler(IMediator mediator, IUserCommandRepository customerCommandRepository, IUserQueryRepository userQueryRepository)
        {
            _mediator = mediator;
            _customerCommandRepository = customerCommandRepository;
            _userQueryRepository = userQueryRepository;
        }
        public async Task<bool> Handle(ValidateOTP request, CancellationToken cancellationToken)
        {
            var userDetail = await _userQueryRepository.GetDetailByEmailId(request.Email);
            if (userDetail != null)
            {
                if (userDetail.TryCount <= 10)
                {
                    if (userDetail.UpdatedDateTime.AddSeconds(60) > DateTime.Now.ToSgt())
                    {
                        if (userDetail.Otp != request.Otp)
                        {
                            userDetail.TryCount++;
                            await _customerCommandRepository.UpdateAsync(userDetail);
                            return false;
                        }
                        else
                        {
                            userDetail.UpdatedDateTime = DateTime.Now.ToSgt();
                            userDetail.TryCount = 0;
                            await _customerCommandRepository.UpdateAsync(userDetail);
                        }
                        return true;
                    }
                    throw new TimeoutException("Timeout for entered Otp");
                }
                return false;
            }
            throw new NotFoundException("Email not found");
        }
    }
}
