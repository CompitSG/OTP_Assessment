﻿using MediatR;
using Microsoft.Extensions.Options;
using OTP.Application.Commands;
using OTP.Application.Extensions;
using OTP.Application.Interface;
using OTP.Application.Mapper;
using OTP.Application.Models;
using OTP.Application.Response;
using OTP.Core.Entities;
using OTP.Core.Repositories.Command;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using OTP.Application.Exceptions;
using OTP.Core.Repositories.Query;
using System.Net.Http;

namespace OTP.Application.Handlers.CommandHandler
{
    public class CreateOtpHandler : IRequestHandler<CreateOtpCommand, CreateUserResponse>
    {
        private readonly IUserCommandRepository _customerCommandRepository;
        private readonly IUserQueryRepository _userQueryRepository;
        private readonly IOptions<EmailConfig> _config;
        private readonly SmtpClient _smtpClient;
        public CreateOtpHandler(IUserCommandRepository customerCommandRepository, IOptions<EmailConfig> config, IUserQueryRepository userQueryRepository)
        {
            _customerCommandRepository = customerCommandRepository;
            _userQueryRepository = userQueryRepository;
            _config = config;
            _smtpClient = new SmtpClient("smtp.gmail.com")
            {
                Port = 587,
                Credentials = new NetworkCredential("pradeep.venkadachalam@gmail.com", "jzovleeufespdztp"),
                EnableSsl = true,
            };
        }
        public async Task<CreateUserResponse> Handle(CreateOtpCommand request, CancellationToken cancellationToken)
        {
            var UserDetail = new UserDetail()
            {
                Email = request.Email,
                CreatedDateTime = DateTime.Now.ToSgt(),
                UpdatedDateTime = DateTime.Now.ToSgt(),
                Id = new Guid(),
                Otp = CreateRandomOtp(),
                TryCount = 0
            };

            var customerEntity = UserMapper.Mapper.Map<UserDetail>(UserDetail);

            if (customerEntity is null)
            {
                throw new ApplicationException("There is a problem in mapper");
            }


            var userDetailData = await _userQueryRepository.GetDetailByEmailId(request.Email);
            if (userDetailData != null)
            {
                if (userDetailData.UpdatedDateTime.AddSeconds(60) > DateTime.Now.ToSgt())
                {
                    throw new DisabledException("Otp already generated, please try after 1 minute");
                }
                userDetailData.Otp =UserDetail.Otp;
                userDetailData.UpdatedDateTime = DateTime.Now.ToSgt();
                userDetailData.TryCount = 0;
                await _customerCommandRepository.UpdateAsync(userDetailData);
                await SendEmail(request.Email, userDetailData.Otp);
            }
            else
            {
                await _customerCommandRepository.AddAsync(customerEntity);
                await SendEmail(request.Email, UserDetail.Otp);
            }
            var customerResponse = UserMapper.Mapper.Map<CreateUserResponse>(customerEntity);
            return customerResponse;
        }

        private int CreateRandomOtp()
        {
            var generator = new Random();
            return generator.Next(0, 1000000);
        }

        private async Task<bool> SendEmail(string email, int? otp)
        {
            try
            {

                var emailData = new EmailDetails()
                {
                    FromEmail = _config.Value.FromEmail,
                    ToEmail = email,
                    Content = $"Your OTP Code is {otp}. The code is valid for 1 minute"
                };
                var _smtpClient = new SmtpClient("smtp.gmail.com")
                {
                    Port = 587,
                    Credentials = new NetworkCredential("gmail", "gmailaccessid"),
                    EnableSsl = true,
                };
                var mailMessage = new MailMessage(emailData.FromEmail," ToEmail", "OTP Verification", emailData.Content);
                await _smtpClient.SendMailAsync(mailMessage);
                return true;
            }
            catch(Exception)
            { return false; }
        }
    }
}