﻿using Microsoft.Extensions.Configuration;
using OTP.Core.Entities;
using OTP.Core.Repositories.Query;
using OTP.InfraStructure.Data;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OTP.InfraStructure.Repository.Query
{
    public class QueryRepository<T> : IQueryRepository<T> where T : class
    {
        protected readonly EmailOtpDbContext _context;

        public QueryRepository(EmailOtpDbContext context)
        {
            _context = context;
        }


        public async Task<UserDetail> GetDetailByEmailId(string emailId)
        {
            return _context.UserDetail.FirstOrDefault(x => x.Email == emailId);
        }
    }
}
