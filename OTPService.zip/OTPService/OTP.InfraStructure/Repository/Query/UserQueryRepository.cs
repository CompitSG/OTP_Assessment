﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using OTP.Core.Entities;
using OTP.Core.Repositories.Command;
using OTP.Core.Repositories.Query;
using OTP.InfraStructure.Data;
using OTP.InfraStructure.Repository.Command;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OTP.InfraStructure.Repository.Query
{
    public class UserQueryRepository : QueryRepository<UserDetail>, IUserQueryRepository
    {
        public UserQueryRepository(EmailOtpDbContext context) : base(context)
        {

        }
    }
}
