﻿using OTP.Core.Entities;
using OTP.Core.Repositories.Command;
using OTP.InfraStructure.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OTP.InfraStructure.Repository.Command
{
    public class UserCommandRepository : CommandRepository<UserDetail>, IUserCommandRepository
    {
        public UserCommandRepository(EmailOtpDbContext context) : base(context)
        {

        }
    }
}

