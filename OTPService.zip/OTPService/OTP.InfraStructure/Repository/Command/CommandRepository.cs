﻿using Microsoft.EntityFrameworkCore;
using OTP.Core.Entities;
using OTP.Core.Repositories.Command;
using OTP.InfraStructure.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OTP.InfraStructure.Repository.Command
{
    public class CommandRepository<T> : ICommandRepository<T> where T : class
    {
        protected readonly EmailOtpDbContext _context;

        public CommandRepository(EmailOtpDbContext context)
        {
            _context = context;
        }

        // Insert
        public async Task<T> AddAsync(T entity)
        {
            await _context.Set<T>().AddAsync(entity);
            await _context.SaveChangesAsync();
            return entity;
        }

        // Update
        public async Task UpdateAsync(T entity)
        {
            _context.Entry(entity).State = EntityState.Modified;
            await _context.SaveChangesAsync();
        }
    }
}
